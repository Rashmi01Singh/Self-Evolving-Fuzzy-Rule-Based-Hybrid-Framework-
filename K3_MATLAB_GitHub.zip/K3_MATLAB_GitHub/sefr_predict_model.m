function [p,left,right,detail] = sefr_predict_model(M,X)
% Fuzzy intervals are type-reduction intervals, NOT statistical confidence intervals.
switch M.kind
    case "fuzzy"
        Z=zeros(size(X,1),numel(M.modules));
        for g=1:numel(M.modules), Z(:,g)=sefr_score_module(M.modules{g},X(:,M.groups{g})); end
        Q=zeros(size(X,1),numel(M.fusion));
        for g=1:numel(M.fusion), Q(:,g)=sefr_score_module(M.fusion{g},Z(:,M.fusionGroups{g})); end
        [p,left,right,activation]=sefr_score_module(M.final,Q);
        if nargout>3, detail=struct('tier1',Z,'tier2',Q,'finalActivation',activation); end
    case "anomaly"
        z=abs((X-M.center)./M.scale); p=1-exp(-max(z,[],2)/5);
        left=p; right=p; detail=struct;
    otherwise
        [~,s]=predict(M.estimator,X);
        j=find(double(M.estimator.ClassNames)==1,1);
        p=s(:,j); left=p; right=p; detail=struct;
end
p=double(p);
assert(all(isfinite(p)),'Nonfinite predictions.');
end
