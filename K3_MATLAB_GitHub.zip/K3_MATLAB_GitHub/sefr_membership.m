function [lower,upper,activation] = sefr_membership(X,M)
% Gaussian uncertain-mean FOU, product t-norm, log-domain common rescaling.
n=size(X,1); k=size(M.center,1); logL=zeros(n,k); logU=logL;
for r=1:k
    distance=abs(X-M.center(r,:));
    logU(:,r)=-0.5*sum((max(0,distance-M.halfWidth)./M.sigma(r,:)).^2,2);
    logL(:,r)=-0.5*sum(((distance+M.halfWidth)./M.sigma(r,:)).^2,2);
end
% Common per-observation multiplier leaves type-reduced ratios unchanged.
offset=max(logU,[],2);
lower=exp(logL-offset); upper=exp(logU-offset);
if nargout>2, activation=(exp(logL)+exp(logU))/2; end
end
