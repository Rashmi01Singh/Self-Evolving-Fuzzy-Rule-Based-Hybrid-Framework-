function D = sefr_load_data(dataset,cfg)
% Official labelled training files only. Kaggle hidden test labels do not exist locally.
folder = fullfile(cfg.root,'data','raw',dataset);
if dataset == "ulb"
    file = fullfile(folder,'creditcard.csv'); require(file);
    T = readtable(file,'VariableNamingRule','preserve');
    assert(all(ismember(["Time","Amount","Class","V1"],string(T.Properties.VariableNames))),'Unexpected ULB schema.');
    D.y = double(T.Class); D.time = T.Time; D.id = (1:height(T))';
    D.names = ["Amount","Time","V"+(1:28)];
    D.X = double(T{:,cellstr(D.names)});
    D.group = [1 4 repmat(2,1,14) repmat(3,1,14)];
    D.groupNames = ["Amount","PCA V1 to V14","PCA V15 to V28","Elapsed time"];
    D.files = string(file);
    D.source = "https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud/data";
    D.expectedRows = 284807; D.expectedFraud = 492;
else
    file = fullfile(folder,'train_transaction.csv'); require(file);
    ident = fullfile(folder,'train_identity.csv'); require(ident);
    % A documented compact feature set keeps full-row runs feasible on 12 GB RAM.
    numeric = ["TransactionAmt","TransactionDT","dist1","dist2","C"+(1:14),"D"+(1:15),"V"+(1:30)];
    categoricalNames = ["ProductCD","card"+(1:6),"addr1","addr2","P_emaildomain","R_emaildomain","M"+(1:9)];
    opts = detectImportOptions(file,'VariableNamingRule','preserve');
    opts.SelectedVariableNames = cellstr(["TransactionID","isFraud",numeric,categoricalNames]);
    opts = setvartype(opts,cellstr(categoricalNames),'string');
    T = readtable(file,opts);
    opts = detectImportOptions(ident,'VariableNamingRule','preserve');
    opts.SelectedVariableNames = cellstr(["TransactionID","id_"+compose('%02d',1:11),"DeviceType","DeviceInfo"]);
    opts = setvartype(opts,{'DeviceType','DeviceInfo'},'string');
    I = readtable(ident,opts);
    assert(numel(unique(T.TransactionID))==height(T),'Duplicate transaction keys.');
    assert(numel(unique(I.TransactionID))==height(I),'Duplicate identity keys.');
    T = outerjoin(T,I,'Keys','TransactionID','MergeKeys',true,'Type','left');
    D.y=double(T.isFraud); D.time=T.TransactionDT; D.id=T.TransactionID;
    D.names = [numeric,categoricalNames,"id_"+compose('%02d',1:11),"DeviceType","DeviceInfo"];
    D.raw = T(:,cellstr(D.names));
    D.X = [];
    D.group = ones(1,numel(D.names));
    D.group(startsWith(D.names,"C") | startsWith(D.names,"D") | startsWith(D.names,"V"))=2;
    D.group(startsWith(D.names,"id_") | startsWith(D.names,"Device"))=3;
    D.group(D.names=="TransactionDT")=4;
    D.groupNames=["Transaction fields","Anonymized C D V fields","Identity fields","Elapsed time"];
    D.files=[string(file),string(ident)]; D.expectedRows=590540; D.expectedFraud=20663;
    D.source="https://www.kaggle.com/competitions/ieee-fraud-detection/data";
end
assert(all(ismember(D.y,[0 1])) && all(isfinite(D.time)),'Invalid labels or time.');
assert(numel(D.y)==D.expectedRows && sum(D.y)==D.expectedFraud,'Official dataset row/fraud counts do not match.');
[~,order]=sortrows([D.time,double(D.id)],[1 2]);
if isfinite(cfg.maxRows), order=order(1:min(numel(order),cfg.maxRows)); end
D.y=D.y(order); D.time=D.time(order); D.id=D.id(order);
if isfield(D,'raw'), D.raw=D.raw(order,:); else, D.X=D.X(order,:); end
end
function require(file)
assert(isfile(file),'SEFR:MissingData','Missing %s. Place the official CSV at this path; see REPRODUCIBILITY.txt.',file);
end
