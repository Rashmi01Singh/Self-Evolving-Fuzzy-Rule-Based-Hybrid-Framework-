function [left,right] = sefr_km_reduce(lower,upper,consequent)
% Karnik-Mendel endpoint iteration for sorted singleton consequents.
assert(all(lower>=0,'all') && all(upper>=lower,'all'),'Invalid firing intervals.');
[z,order]=sort(consequent(:)'); lower=lower(:,order); upper=upper(:,order);
w=(lower+upper)/2; base=(w*z')./max(sum(w,2),realmin);
left=endpoint(base,true); right=endpoint(base,false);
assert(all(left<=right+1e-9),'Karnik-Mendel interval ordering failed.');
    function result=endpoint(result,isLeft)
        for iteration=1:100
            useUpper=(z<=result);
            if ~isLeft, useUpper=~useUpper; end
            weights=lower+(upper-lower).*useUpper;
            next=(weights*z')./max(sum(weights,2),realmin);
            if max(abs(next-result))<1e-11, result=next; return; end
            result=next;
        end
        error('SEFR:KM','Type reduction did not converge.');
    end
end
