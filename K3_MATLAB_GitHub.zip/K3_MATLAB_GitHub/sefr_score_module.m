function [score,left,right,activation] = sefr_score_module(M,X)
[lower,upper,activation]=sefr_membership(X,M);
[left,right]=sefr_km_reduce(lower,upper,M.consequent);
score=(left+right)/2;
end
