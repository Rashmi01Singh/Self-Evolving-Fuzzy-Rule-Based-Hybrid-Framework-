function sefr_write_exact_csv(T,file)
% Preserve IEEE double round trips; writetable may round near-tied scores.
fid=fopen(file,'w'); assert(fid>=0,'Cannot open CSV.'); cleanup=onCleanup(@()fclose(fid));
fprintf(fid,'%s\n',strjoin(string(T.Properties.VariableNames),','));
isnum=varfun(@(x)isnumeric(x)||islogical(x),T,'OutputFormat','uniform');
if all(isnum)
    fmt=char(strjoin(repmat("%.17g",1,width(T)),',')+newline);
    fprintf(fid,fmt,double(T{:,:})');
else
    for row=1:height(T)
        values=strings(1,width(T));
        for col=1:width(T)
            value=T{row,col};
            if isnum(col), values(col)=compose('%.17g',double(value));
            else, values(col)='"'+replace(string(value),'"','""')+'"'; end
        end
        fprintf(fid,'%s\n',strjoin(values,','));
    end
end
end
