function f = open_manuscript_figure(label,profile)
% Open an editable figure using its manuscript label, for example '5b'.
arguments
    label (1,1) string = "5b"
    profile (1,1) string {mustBeMember(profile,["full","quick"])} = "full"
end
label=lower(strtrim(label));
assert(~isempty(regexp(label,'^[1-9][0-9]*[a-z]?$','once')), ...
    'Use a manuscript label such as 5b or 9.');
root=fileparts(mfilename('fullpath'));
file=fullfile(root,'results',profile,'manuscript_figures',"Figure_"+label+".fig");
assert(isfile(file),'Missing %s. Run the corresponding dataset first.',file);
f=openfig(file,'new','visible');
set(f,'WindowStyle','normal','Resize','on','MenuBar','figure', ...
    'ToolBar','figure','NumberTitle','off','Name',char("Figure "+label));
movegui(f,'onscreen');
plotedit(f,'on');
end
