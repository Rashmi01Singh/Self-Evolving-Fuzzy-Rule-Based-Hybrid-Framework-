function sefr_make_figures(out)
% Regenerate every chart exclusively from saved MATLAB experiment outputs.
S=load(fullfile(out,'experiment.mat')); M=S.metrics; H=S.models{8};
folder=fullfile(out,'figures'); if ~isfolder(folder), mkdir(folder); end
set(groot,'defaultAxesFontName','Arial','defaultAxesFontSize',15,'defaultLineLineWidth',1.6);
colors=lines(height(M)); colors(end,:)=[0 0 0]; tag=upper(string(S.manifest.dataset));
shortNames=["Anomaly rules","Logistic reg.","Random forest","LogitBoost","Type1 static","Type2 static","Type1 evolving","SEFR-HF recon."];

f=figure('Visible','off','Color','w','Position',[100 100 950 560]);
module=H.modules{1}; center=module.center(1,1); sigma=module.sigma(1,1); delta=module.halfWidth;
x=linspace(0,1,501)'; upperMF=exp(-max(0,abs(x-center)-delta).^2/(2*sigma^2)); lowerMF=exp(-(abs(x-center)+delta).^2/(2*sigma^2));
fill([x;flipud(x)],[upperMF;flipud(lowerMF)],[.78 .86 .96],'EdgeColor','none'); hold on;
plot(x,upperMF,'Color',[.1 .3 .6]); plot(x,lowerMF,'--','Color',[.7 .2 .12]);
xlabel('Train-scaled feature value'); ylabel('Membership'); ylim([0 1.05]); grid on;
title(sprintf('%s fitted rule 1: mean %.3f, spread %.3f',tag,center,sigma));
legend('Footprint of uncertainty','Upper membership','Lower membership','Location','best');
saveFigure(f,'figure01_fitted_membership');
writetable(table(x,lowerMF,upperMF),fullfile(folder,'figure01_source.csv'));

f=figure('Visible','off','Color','w','Position',[100 100 1050 520]); axis off;
text(.5,.94,tag+" executed experiment",'HorizontalAlignment','center','FontSize',17,'FontWeight','bold');
labels={sprintf('Official labelled CSV\n%d rows; %d frauds',S.manifest.rowCount,S.manifest.fraudCount), ...
    sprintf('Chronological training\n%d rows; %d frauds',S.datasetTable.Rows(1),S.datasetTable.Fraud(1)), ...
    sprintf('Validation threshold\n%d rows; %d frauds',S.datasetTable.Rows(2),S.datasetTable.Fraud(2)), ...
    sprintf('Untouched test set\n%d rows; %d frauds',S.datasetTable.Rows(3),S.datasetTable.Fraud(3))};
positions=[.06 .64 .38 .17;.56 .64 .38 .17;.06 .25 .38 .17;.56 .25 .38 .17];
for k=1:4, annotation(f,'textbox',positions(k,:),'String',labels{k},'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',13,'BackgroundColor',[.95 .97 .99],'LineWidth',1); end
annotation(f,'arrow',[.45 .55],[.725 .725]); annotation(f,'arrow',[.74 .27],[.63 .43]); annotation(f,'arrow',[.45 .55],[.335 .335]);
text(.5,.055,'Scaling and encodings fitted on training only. Test labels never tune models.','HorizontalAlignment','center','FontSize',11);
saveFigure(f,'figure02_experiment_flow');

f=figure('Visible','off','Color','w','Position',[100 100 1000 620]);
F=S.featureTable(S.featureTable.UsedByFuzzy,:); [~,ix]=sort(F.TrainAUCDistance); F=F(ix,:);
barh(F.TrainAUCDistance,'FaceColor',[.12 .4 .65]); yticks(1:height(F)); yticklabels(F.Feature); set(gca,'TickLabelInterpreter','none');
xlabel('Absolute training univariate ROC AUC minus 0.5'); title(tag+" selected fuzzy inputs"); grid on;
saveFigure(f,'figure03_selected_features'); writetable(F,fullfile(folder,'figure03_source.csv'));

f=figure('Visible','off','Color','w','Position',[100 100 1050 590]); axis off;
text(.5,.96,tag+" trained fuzzy hierarchy",'HorizontalAlignment','center','FontSize',17,'FontWeight','bold');
for g=1:numel(H.modules)
    pos=[.03+(g-1)*.245 .69 .22 .16];
    annotation(f,'textbox',pos,'String',sprintf('Feature group %d\n%d inputs | %d rules',g,numel(H.groups{g}),size(H.modules{g}.center,1)), ...
        'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',12,'BackgroundColor',[.93 .96 .99]);
    target=.25; if g>2, target=.75; end
    annotation(f,'arrow',[pos(1)+.11 target],[.68 .52]);
end
for g=1:numel(H.fusion)
    annotation(f,'textbox',[.12+(g-1)*.5 .35 .26 .17],'String',sprintf('Fusion module %d\n%d rules',g,size(H.fusion{g}.center,1)), ...
        'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',12,'BackgroundColor',[.94 .97 .94]);
    annotation(f,'arrow',[.25+(g-1)*.5 .5],[.34 .21]);
end
annotation(f,'textbox',[.33 .05 .34 .16],'String',sprintf('Final risk module | %d rules\nValidation threshold %.4f',size(H.final.center,1),M.Threshold(8)), ...
    'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',12,'BackgroundColor',[.99 .96 .91]);
saveFigure(f,'figure04_trained_hierarchy');

f=figure('Visible','off','Color','w','Position',[100 100 1050 620]); tiledlayout(2,1,'TileSpacing','compact');
T=S.trace; nexttile;
stairs(T.EndElapsedDays,T.FinalRules,'-o','Color',[.1 .4 .65]); ylabel('Tier 1 rules'); grid on;
title(tag+" chronological evolution within training");
nexttile; plot(T.EndElapsedDays,T.PrequentialRecall,'-o'); hold on; plot(T.EndElapsedDays,T.PrequentialF1,'-s');
ylabel('Pre-update recall / F1'); xlabel('Elapsed days from dataset reference'); ylim([0 1]); grid on;
legend('Recall','F1','Location','best');
saveFigure(f,'figure05_rule_evolution'); writetable(T,fullfile(folder,'figure05_source.csv'));

f=figure('Visible','off','Color','w','Position',[100 100 1200 650]);
bar([M.Sensitivity M.Specificity M.F1]); xticks(1:height(M)); xticklabels(shortNames); xtickangle(24);
ylabel('Held-out test metric'); ylim([0 1.05]); grid on;
legend('Recall','Specificity','F1','Location','southoutside','Orientation','horizontal');
title(sprintf('%s test results at observed prevalence %.4f%%',tag,100*M.Prevalence(1)));
saveFigure(f,'figure06_test_comparison'); writetable(M,fullfile(folder,'figure06_source.csv'));

f=figure('Visible','off','Color','w','Position',[100 100 1200 580]); tiledlayout(1,2,'TileSpacing','compact');
nexttile; hold on;
for k=1:height(M), plot(S.curves{k}.fpr,S.curves{k}.tpr,'Color',colors(k,:)); end
xlabel('False positive rate'); ylabel('True positive rate'); title(tag+" test ROC"); grid on;
nexttile; hold on;
for k=1:height(M), stairs(S.curves{k}.recall,S.curves{k}.precision,'Color',colors(k,:)); end
xlabel('Recall'); ylabel('Precision'); title(tag+" test precision recall"); grid on;
legend(shortNames,'Location','eastoutside','Interpreter','none','FontSize',12);
saveFigure(f,'figure07_roc_precision_recall');

f=figure('Visible','off','Color','w','Position',[100 100 1100 560]);
bar([M.SingleMeanMs M.SingleP95Ms]); xticks(1:height(M)); xticklabels(shortNames); xtickangle(25); grid on;
ylabel('Milliseconds per single model call'); title(tag+" measured CPU latency after warm-up");
legend('Mean','95th percentile','Location','northwest');
saveFigure(f,'figure08_cpu_latency');

f=figure('Visible','off','Color','w','Position',[100 100 1000 450]); tiledlayout(1,2);
nexttile; imagesc([M.TN(8) M.FP(8);M.FN(8) M.TP(8)]); colormap(parula); colorbar;
xticks([1 2]); yticks([1 2]); xticklabels({'Legitimate','Fraud'}); yticklabels({'Legitimate','Fraud'});
xlabel('Predicted'); ylabel('Actual'); title('SEFR-HF reconstruction test counts');
C=[M.TN(8) M.FP(8);M.FN(8) M.TP(8)];
for row=1:2
    for col=1:2
        color='w'; if C(row,col)>.5*max(C,[],'all'), color='k'; end
        text(col,row,string(C(row,col)),'HorizontalAlignment','center','FontWeight','bold','Color',color,'FontSize',15);
    end
end
nexttile; histogram(S.intervals(:,2)-S.intervals(:,1),30); xlabel('Right endpoint minus left endpoint'); ylabel('Test transactions'); title('Type-reduction interval widths'); grid on;
saveFigure(f,'figure09_confusion_uncertainty');
figureManifest=struct('renderer',mfilename('fullpath'),'sha256',sefr_hash_file(mfilename('fullpath')+".m"),'generatedUTC',char(datetime('now','TimeZone','UTC')));
fid=fopen(fullfile(folder,'figure_manifest.json'),'w'); fprintf(fid,'%s',jsonencode(figureManifest,'PrettyPrint',true)); fclose(fid);

export_manuscript_figures(out);

    function saveFigure(fig,name)
        % Print the full canvas to retain breathing room around titles and labels.
        pos=getpixelposition(fig); inches=pos(3:4)/96;
        set(fig,'PaperUnits','inches','PaperSize',inches,'PaperPosition',[0 0 inches]);
        print(fig,fullfile(folder,name+".png"),'-dpng','-r220');
        print(fig,fullfile(folder,name+".pdf"),'-dpdf','-painters');
        % FIG files retain Visible='off' unless explicitly changed before saving.
        % Keep native graphics, normal editing menus and a resizable window.
        set(fig,'WindowStyle','normal','Resize','on','MenuBar','figure', ...
            'ToolBar','figure','Visible','on');
        savefig(fig,fullfile(folder,name+".fig")); close(fig);
    end
end
