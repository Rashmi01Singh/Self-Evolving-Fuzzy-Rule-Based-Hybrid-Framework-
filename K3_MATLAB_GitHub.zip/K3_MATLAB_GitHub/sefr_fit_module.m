function M = sefr_fit_module(X,y,cfg,halfWidth)
% Class-specific data prototypes; singleton consequents, not a fabricated expert rule base.
M.center=[]; M.sigma=[]; M.consequent=[]; M.halfWidth=halfWidth;
for label=0:1
    ix=find(y==label);
    assert(~isempty(ix),'SEFR:SingleClass','Both classes are needed in each fuzzy fitting block.');
    if numel(ix)>cfg.maxClusterRows, ix=ix(randperm(numel(ix),cfg.maxClusterRows)); end
    k=min(cfg.rulesPerClass,size(unique(X(ix,:),'rows'),1));
    [cluster,C]=kmeans(X(ix,:),k,'MaxIter',100,'Replicates',1,'EmptyAction','singleton');
    S=zeros(size(C));
    for r=1:k
        S(r,:)=std(X(ix(cluster==r),:),0,1);
    end
    S(~isfinite(S))=cfg.sigmaMin;
    S=min(cfg.sigmaMax,max(cfg.sigmaMin,S));
    M.center=[M.center;C]; M.sigma=[M.sigma;S]; %#ok<AGROW>
    M.consequent=[M.consequent;repmat(label,k,1)]; %#ok<AGROW>
end
end
