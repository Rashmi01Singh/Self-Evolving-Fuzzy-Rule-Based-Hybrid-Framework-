function summary = run_all(dataset, profile)
% RUN_ALL Reproduce real-data MATLAB experiments. No synthetic fallback.
%   run_all('ulb'); run_all('ieee'); run_all('all'); run_all('ulb','quick')
if nargin < 1, dataset = "all"; end
if nargin < 2, profile = "full"; end
root = fileparts(mfilename('fullpath'));
addpath(root);
cfg = default_config(root);
cfg.profile = string(profile);
if cfg.profile == "quick"
    cfg.forestTrees = 20; cfg.boostTrees = 20;
    cfg.bootstrapReplicates = 30; cfg.latencyRows = 20;
elseif cfg.profile ~= "full"
    error('SEFR:Profile','Profile must be full or quick.');
end
if string(dataset) ~= "all", cfg.datasets = string(dataset); end
assert(all(ismember(cfg.datasets,["ulb","ieee"])),'Unknown dataset.');
assert(license('test','Statistics_Toolbox'),'Statistics and Machine Learning Toolbox is required.');
summary = struct;
for dataset = cfg.datasets
    out = fullfile(root,'results',cfg.profile,dataset);
    if ~isfolder(out), mkdir(out); end
    diary(fullfile(out,'matlab_run.log')); cleanup = onCleanup(@() diary('off'));
    fprintf('Dataset %s, profile %s, MATLAB %s\n',dataset,cfg.profile,version);
    try
        summary.(dataset) = sefr_run_dataset(dataset,cfg,out);
    catch err
        fid=fopen(fullfile(out,'FAILED.txt'),'w'); fprintf(fid,'%s',getReport(err,'extended','hyperlinks','off')); fclose(fid);
        rethrow(err);
    end
    clear cleanup
end
end
