function [modules,trace] = sefr_evolve_modules(modules,groups,X,y,time,cfg)
% Predict each new block before seeing its labels. Propose on the first 60%,
% then gate once on the disjoint later 40%. No gate rows are reused later.
edges=round(linspace(0,numel(y),cfg.evolutionBlocks+1)); rows=cell(1,cfg.evolutionBlocks);
for b=1:cfg.evolutionBlocks
    ix=(edges(b)+1:edges(b+1))';
    cut=floor(cfg.proposalFraction*numel(ix)); proposal=ix(1:cut); gate=ix(cut+1:end);
    before=score(modules,X(ix,:));
    metrics=sefr_metrics(y(ix),before,0.5);
    currentCount=sum(cellfun(@(m)size(m.center,1),modules));
    candidate=modules; added=0; modified=0; deleted=0;
    operation=mod(b-1,3)+1;
    if numel(unique(y(proposal)))==2 && numel(unique(y(gate)))==2
        for g=1:numel(modules)
            M=candidate{g}; U=X(proposal,groups{g}); labels=y(proposal);
            [p,~,~,activation]=sefr_score_module(M,U);
            if operation==1 && size(M.center,1)<cfg.maxRules
                err=abs(p-labels); uncovered=max(activation,[],2)<cfg.thetaFire;
                eligible=find(err>cfg.thetaAdd & uncovered);
                if ~isempty(eligible)
                    [~,ii]=max(err(eligible)); j=eligible(ii);
                    M.center(end+1,:)=U(j,:); M.sigma(end+1,:)=max(cfg.sigmaMin,median(M.sigma,1));
                    M.consequent(end+1)=labels(j); added=added+1;
                end
            elseif operation==2
                active=activation>cfg.thetaFire;
                correct=(labels==M.consequent');
                accuracy=sum(active & correct,1)./max(sum(active,1),1);
                candidates=find(accuracy<cfg.thetaModify & sum(active,1)>0);
                if ~isempty(candidates)
                    [~,ii]=min(accuracy(candidates)); rule=candidates(ii);
                    % Finite-difference gradient of weighted cross entropy wrt means.
                    subset=[find(labels==1);find(labels==0, min(1000,sum(labels==0)))];
                    gradient=zeros(1,size(U,2));
                    for d=1:size(U,2)
                        plus=M; minus=M;
                        plus.center(rule,d)=plus.center(rule,d)+cfg.gradientStep;
                        minus.center(rule,d)=minus.center(rule,d)-cfg.gradientStep;
                        gradient(d)=(sefr_balanced_loss(labels(subset),sefr_score_module(plus,U(subset,:)))-sefr_balanced_loss(labels(subset),sefr_score_module(minus,U(subset,:))))/(2*cfg.gradientStep);
                    end
                    M.center(rule,:)=min(1,max(0,M.center(rule,:)-cfg.learningRate*max(-1,min(1,gradient))));
                    modified=modified+1;
                end
            elseif operation==3 && size(M.center,1)>2
                rate=mean(activation>cfg.thetaFire,1);
                [low,j]=min(rate);
                if low<cfg.thetaDelete && sum(M.consequent==M.consequent(j))>1
                    M.center(j,:)=[]; M.sigma(j,:)=[]; M.consequent(j)=[]; deleted=deleted+1;
                end
            end
            candidate{g}=M;
        end
        oldObjective=sefr_balanced_loss(y(gate),score(modules,X(gate,:)))+cfg.complexityPenalty*currentCount;
        count=sum(cellfun(@(m)size(m.center,1),candidate));
        newObjective=sefr_balanced_loss(y(gate),score(candidate,X(gate,:)))+cfg.complexityPenalty*count;
        accepted=newObjective<oldObjective-cfg.gateImprovement;
    else
        oldObjective=NaN; newObjective=NaN; accepted=false;
    end
    if accepted, modules=candidate; end
    r.Block=b; r.StartElapsedDays=time(ix(1))/86400; r.EndElapsedDays=time(ix(end))/86400;
    r.Rows=numel(ix); r.Fraud=sum(y(ix)); r.ProposalFraud=sum(y(proposal)); r.GateFraud=sum(y(gate));
    r.InitialRules=currentCount; r.ProposedAdd=added; r.ProposedModify=modified; r.ProposedDelete=deleted;
    r.Accepted=accepted; r.Added=added*accepted; r.Modified=modified*accepted; r.Deleted=deleted*accepted;
    r.FinalRules=sum(cellfun(@(m)size(m.center,1),modules));
    r.GateBefore=oldObjective; r.GateAfter=newObjective;
    r.PrequentialAccuracy=metrics.Accuracy; r.PrequentialRecall=metrics.Sensitivity;
    r.PrequentialF1=metrics.F1; r.PrequentialROCAUC=metrics.ROCAUC;
    rows{b}=r;
end
trace=struct2table([rows{:}]);
    function p=score(models,U)
        S=zeros(size(U,1),numel(models));
        for k=1:numel(models), S(:,k)=sefr_score_module(models{k},U(:,groups{k})); end
        p=mean(S,2);
    end
end
