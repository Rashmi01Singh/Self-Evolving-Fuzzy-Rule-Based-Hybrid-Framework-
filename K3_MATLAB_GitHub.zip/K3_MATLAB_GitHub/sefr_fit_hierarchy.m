function [H,trace] = sefr_fit_hierarchy(X,y,time,groups,cfg,type2,evolve)
% Training chronology: 50% prototypes, 30% evolution, 10% tier 2, 10% tier 3.
n=numel(y); a=floor(.5*n); b=floor(.8*n); c=floor(.9*n);
fit=(1:a)'; stream=(a+1:b)'; fusion=(b+1:c)'; final=(c+1:n)';
halfWidth=cfg.fouHalfWidth*type2;
H.kind="fuzzy"; H.groups=groups; H.modules=cell(1,numel(groups));
for g=1:numel(groups), H.modules{g}=sefr_fit_module(X(fit,groups{g}),y(fit),cfg,halfWidth); end
H.initialModules=H.modules;
trace=table;
if evolve
    [H.modules,trace]=sefr_evolve_modules(H.modules,groups,X(stream,:),y(stream),time(stream),cfg);
end
Z=stage1(H,X(fusion,:));
H.fusionGroups={1:min(2,size(Z,2)),3:size(Z,2)};
H.fusionGroups=H.fusionGroups(~cellfun(@isempty,H.fusionGroups));
H.fusion=cell(size(H.fusionGroups));
for g=1:numel(H.fusion), H.fusion{g}=sefr_fit_module(Z(:,H.fusionGroups{g}),y(fusion),cfg,halfWidth); end
Z=stage1(H,X(final,:)); Q=zeros(size(Z,1),numel(H.fusion));
for g=1:numel(H.fusion), Q(:,g)=sefr_score_module(H.fusion{g},Z(:,H.fusionGroups{g})); end
H.final=sefr_fit_module(Q,y(final),cfg,halfWidth);
H.ruleCount=sum(cellfun(@(m)size(m.center,1),H.modules))+sum(cellfun(@(m)size(m.center,1),H.fusion))+size(H.final.center,1);
H.trainingRows=struct('prototypes',numel(fit),'evolution',numel(stream),'tier2',numel(fusion),'tier3',numel(final));
end
function Z=stage1(H,X)
Z=zeros(size(X,1),numel(H.modules));
for g=1:numel(H.modules), Z(:,g)=sefr_score_module(H.modules{g},X(:,H.groups{g})); end
end
