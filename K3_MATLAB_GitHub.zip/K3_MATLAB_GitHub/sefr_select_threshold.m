function threshold = sefr_select_threshold(y,score)
% Highest threshold among validation F1 ties. Never receives test labels.
[~,c]=sefr_metrics(y,score,0.5);
[~,i]=max(c.f1); threshold=c.threshold(i);
end
