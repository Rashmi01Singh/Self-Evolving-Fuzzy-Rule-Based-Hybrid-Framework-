function export_manuscript_figures(datasetFolder)
% Copy generated MATLAB figures to the manuscript's a/b labels.
[profileFolder,dataset]=fileparts(datasetFolder);
if strcmp(dataset,'ulb')
    labels={'1','2','3a','5a','6a','7a','8a','9'};
    numbers=[1 2 3 5 6 7 8 9];
elseif strcmp(dataset,'ieee')
    labels={'3b','4','5b','6b','7b','8b'};
    numbers=[3 4 5 6 7 8];
else
    error('SEFR:Dataset','Expected a dataset folder named ulb or ieee.');
end
destination=fullfile(profileFolder,'manuscript_figures');
if ~isfolder(destination), mkdir(destination); end
for k=1:numel(labels)
    for extension={'.fig','.png','.pdf'}
        files=dir(fullfile(datasetFolder,'figures', ...
            sprintf('figure%02d_*%s',numbers(k),extension{1})));
        assert(numel(files)==1,'Missing or ambiguous generated figure %d.',numbers(k));
        copyfile(fullfile(files(1).folder,files(1).name), ...
            fullfile(destination,['Figure_' labels{k} extension{1}]),'f');
    end
end
end
