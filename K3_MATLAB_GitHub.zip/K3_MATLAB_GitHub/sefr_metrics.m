function [m,curve] = sefr_metrics(y,score,threshold)
% Tie-aware ROC AUC and step-integrated average precision at observed prevalence.
y=double(y(:)); score=double(score(:));
assert(numel(y)==numel(score) && all(isfinite(score)) && all(ismember(y,[0,1])),'Invalid predictions.');
pred=score>=threshold; tp=sum(pred & y==1); fp=sum(pred & y==0);
fn=sum(~pred & y==1); tn=sum(~pred & y==0);
m.N=numel(y); m.Fraud=sum(y); m.Prevalence=mean(y);
m.TP=tp; m.FP=fp; m.TN=tn; m.FN=fn;
m.Threshold=threshold; m.Sensitivity=ratio(tp,tp+fn); m.Specificity=ratio(tn,tn+fp);
m.Precision=ratio(tp,tp+fp); m.F1=ratio(2*tp,2*tp+fp+fn);
m.MCC=ratio(tp*tn-fp*fn,sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)));
m.Accuracy=ratio(tp+tn,numel(y)); m.FPR=ratio(fp,fp+tn);
[s,order]=sort(score,'descend'); ys=y(order);
ends=[find(diff(s)~=0);numel(s)]; ctp=cumsum(ys); cfp=cumsum(1-ys);
tpv=[0;ctp(ends)]; fpv=[0;cfp(ends)];
curve.threshold=[Inf;s(ends)]; curve.tpr=tpv/max(sum(y),1); curve.fpr=fpv/max(sum(1-y),1);
curve.precision=[1;ctp(ends)./max(ctp(ends)+cfp(ends),1)]; curve.recall=curve.tpr;
curve.f1=2*tpv./max(2*tpv+fpv+sum(y)-tpv,1);
m.ROCAUC=trapz(curve.fpr,curve.tpr);
m.AveragePrecision=sum(diff(curve.recall).*curve.precision(2:end));
if numel(unique(y))<2, m.ROCAUC=NaN; m.AveragePrecision=NaN; end
end
function v=ratio(a,b)
if b==0, v=0; else, v=a/b; end
end
