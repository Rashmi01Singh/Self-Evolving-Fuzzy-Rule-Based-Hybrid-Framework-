function result = sefr_run_dataset(dataset,cfg,out)
rng(cfg.seed,'twister'); started=datetime('now','TimeZone','UTC');
D=sefr_load_data(dataset,cfg); n=numel(D.y);
a=floor(n*cfg.trainFraction); b=floor(n*(cfg.trainFraction+cfg.validationFraction));
% Do not split transactions with the same timestamp across partitions.
while a<n && D.time(a)==D.time(a+1), a=a+1; end
while b<n && D.time(b)==D.time(b+1), b=b+1; end
train=(1:a)'; validation=(a+1:b)'; test=(b+1:n)';
assert(D.time(train(end))<D.time(validation(1)) && D.time(validation(end))<D.time(test(1)),'Time overlap.');
assert(all([sum(D.y(train)),sum(D.y(validation)),sum(D.y(test))]>0),'Every split needs fraud cases.');
[X,P]=sefr_preprocess(D,train);
% Select at most four features per group by train-only univariate AUC, using
% only the prototype-fit part of training; retain all selected fields for ML baselines.
prototype=train(1:floor(.5*numel(train))); strength=zeros(1,size(X,2));
for j=1:size(X,2)
    m=sefr_metrics(D.y(prototype),X(prototype,j),.5); strength(j)=abs(m.ROCAUC-.5);
end
groups=cell(1,numel(D.groupNames));
for g=1:numel(groups)
    candidate=find(D.group==g); [~,rank]=sort(strength(candidate),'descend');
    groups{g}=candidate(rank(1:min(cfg.featuresPerGroup,numel(rank))));
end
splitName=strings(n,1); splitName(train)="train"; splitName(validation)="validation"; splitName(test)="test";
writetable(table(D.id,D.time,D.y,splitName,'VariableNames',{'RowID','ElapsedSeconds','Label','Split'}),fullfile(out,'split_assignments.csv'));
datasetTable=table(["Train";"Validation";"Test"],[numel(train);numel(validation);numel(test)], ...
    [sum(D.y(train));sum(D.y(validation));sum(D.y(test))], ...
    [mean(D.y(train));mean(D.y(validation));mean(D.y(test))], ...
    [D.time(train(1));D.time(validation(1));D.time(test(1))]/86400, ...
    [D.time(train(end));D.time(validation(end));D.time(test(end))]/86400, ...
    'VariableNames',{'Split','Rows','Fraud','Prevalence','StartElapsedDays','EndElapsedDays'});
writetable(datasetTable,fullfile(out,'dataset_summary.csv'));
featureTable=table(D.names',D.group',strength',false(numel(D.names),1),'VariableNames',{'Feature','Group','TrainAUCDistance','UsedByFuzzy'});
featureTable.UsedByFuzzy([groups{:}])=true; writetable(featureTable,fullfile(out,'feature_manifest.csv'));
methods=["Anomaly rules","Logistic regression","Random forest","LogitBoost","Type1 static","Type2 static","Type1 evolving","SEFR-HF reconstruction"];
rows=cell(size(methods)); curves=cell(size(methods)); predictions=zeros(numel(test),numel(methods));
models=cell(size(methods)); intervals=zeros(numel(test),2); trace=table; timing=table;
for method=1:numel(methods)
    rng(cfg.seed,'twister'); fprintf('Training %s\n',methods(method)); clock=tic;
    M=struct; localTrace=table;
    if method==1
        M.kind="anomaly"; M.center=median(X(train(D.y(train)==0),:),1);
        M.scale=1.4826*median(abs(X(train(D.y(train)==0),:)-M.center),1); M.scale=max(M.scale,.02);
    elseif method==2
        M.kind="linear";
        M.estimator=fitclinear(X(train,:),D.y(train),'Learner','logistic','Regularization','ridge','Lambda',1e-4,'Solver','lbfgs','Prior','uniform','ClassNames',[0;1]);
    elseif method==3
        M.kind="ensemble";
        tree=templateTree('MaxNumSplits',255,'MinLeafSize',5,'NumVariablesToSample',max(1,floor(sqrt(size(X,2)))));
        M.estimator=fitcensemble(X(train,:),D.y(train),'Method','Bag','NumLearningCycles',cfg.forestTrees,'Learners',tree,'Prior','uniform','ClassNames',[0;1]);
    elseif method==4
        M.kind="ensemble";
        tree=templateTree('MaxNumSplits',15,'MinLeafSize',10);
        M.estimator=fitcensemble(X(train,:),D.y(train),'Method','LogitBoost','NumLearningCycles',cfg.boostTrees,'LearnRate',.1,'Learners',tree,'Prior','uniform','ClassNames',[0;1]);
    else
        [M,localTrace]=sefr_fit_hierarchy(X(train,:),D.y(train),D.time(train),groups,cfg,ismember(method,[6,8]),method>=7);
    end
    trainSeconds=toc(clock);
    valScore=sefr_predict_model(M,X(validation,:)); threshold=sefr_select_threshold(D.y(validation),valScore);
    [valMetric,valCurve]=sefr_metrics(D.y(validation),valScore,threshold);
    writetable(table(valCurve.threshold,valCurve.f1,valCurve.tpr,valCurve.fpr,'VariableNames',{'Threshold','F1','Recall','FPR'}),fullfile(out,sprintf('validation_thresholds_%02d.csv',method)));
    % Warm-up outside measured latency. Full test scoring uses bounded batches.
    sefr_predict_model(M,X(test(1:min(50,numel(test))),:));
    p=zeros(numel(test),1); lo=p; hi=p; clock=tic;
    for start=1:cfg.batchSize:numel(test)
        ix=start:min(start+cfg.batchSize-1,numel(test));
        [p(ix),lo(ix),hi(ix)]=sefr_predict_model(M,X(test(ix),:));
    end
    batchSeconds=toc(clock);
    % Repeated single-row calls measure model-only latency on evenly spaced test rows.
    latencyIx=round(linspace(1,numel(test),min(cfg.latencyRows,numel(test)))); latency=zeros(numel(latencyIx),1);
    for j=1:numel(latencyIx), clock=tic; sefr_predict_model(M,X(test(latencyIx(j)),:)); latency(j)=toc(clock)*1000; end
    [r,curves{method}]=sefr_metrics(D.y(test),p,threshold);
    r.Method=methods(method); r.ValidationF1=valMetric.F1; r.TrainSeconds=trainSeconds;
    r.BatchMsPerRow=batchSeconds*1000/numel(test); r.SingleMeanMs=mean(latency); r.SingleP95Ms=quantile(latency,.95);
    if M.kind=="fuzzy", r.Rules=M.ruleCount; else, r.Rules=0; end
    rows{method}=r; models{method}=M; predictions(:,method)=p;
    CI=sefr_bootstrap_ci(D.y(test),p,threshold,cfg.bootstrapReplicates);
    writetable(CI,fullfile(out,sprintf('confidence_intervals_%02d.csv',method)));
    writetable(table(curves{method}.fpr,curves{method}.tpr,curves{method}.precision,curves{method}.recall,curves{method}.threshold,'VariableNames',{'FPR','TPR','Precision','Recall','Threshold'}),fullfile(out,sprintf('test_curves_%02d.csv',method)));
    if method==8, intervals=[lo hi]; trace=localTrace; end
    if ~isempty(localTrace), writetable(localTrace,fullfile(out,sprintf('evolution_%02d.csv',method))); end
    fprintf('Test F1 %.4f | ROC AUC %.4f | AP %.4f | recall %.4f\n',r.F1,r.ROCAUC,r.AveragePrecision,r.Sensitivity);
    save(fullfile(out,sprintf('model_%02d.mat',method)),'M','P','threshold','cfg','-v7.3');
end
metrics=struct2table([rows{:}]); metrics=movevars(metrics,'Method','Before',1);
sefr_write_exact_csv(metrics,fullfile(out,'metrics.csv'));
sefr_write_exact_csv(metrics(5:8,:),fullfile(out,'ablation.csv'));
predTable=array2table(predictions,'VariableNames',cellstr(matlab.lang.makeValidName(methods)));
predTable=addvars(predTable,D.id(test),D.y(test),'Before',1,'NewVariableNames',{'RowID','Label'});
predTable.TypeReducedLeft=intervals(:,1); predTable.TypeReducedRight=intervals(:,2);
sefr_write_exact_csv(predTable,fullfile(out,'test_predictions.csv'));
% Explain a fixed test subset using anonymized feature names and strongest rules.
[~,~,~,detail]=sefr_predict_model(models{8},X(test(1:min(20,numel(test))),:));
[~,topRule]=max(detail.finalActivation,[],2);
writetable(table(D.id(test(1:numel(topRule))),topRule,predictions(1:numel(topRule),8),'VariableNames',{'RowID','TopFinalRule','FraudScore'}),fullfile(out,'explanations.csv'));
manifest=struct('dataset',dataset,'source',D.source,'profile',cfg.profile,'seed',cfg.seed,'matlabVersion',version,'architecture',computer, ...
    'startedUTC',char(started),'finishedUTC',char(datetime('now','TimeZone','UTC')), ...
    'rowCount',n,'fraudCount',sum(D.y),'cfg',cfg,'toolboxes',ver,'dataFiles',struct([]), ...
    'methodStatus','Paper-informed reconstruction; not exact reproduction; no merchant-fraud labels', ...
    'thresholdPolicy','Validation maximum F1 with highest-threshold tie break', ...
    'intervalPolicy','Stratified IID bootstrap conditional on observed counts; temporal dependence not modelled');
for j=1:numel(D.files)
    info=dir(D.files(j)); item=struct('name',info.name,'bytes',info.bytes,'sha256',sefr_hash_file(D.files(j)));
    if j==1, manifest.dataFiles=item; else, manifest.dataFiles(j)=item; end
end
manifest.sourceFiles=struct([]); code=dir(fullfile(cfg.root,'**','*.m'));
for j=1:numel(code)
    file=fullfile(code(j).folder,code(j).name); item=struct('path',erase(string(file),string(cfg.root)+filesep),'sha256',sefr_hash_file(file));
    if j==1, manifest.sourceFiles=item; else, manifest.sourceFiles(j)=item; end
end
fid=fopen(fullfile(out,'run_manifest.json'),'w'); fprintf(fid,'%s',jsonencode(manifest,'PrettyPrint',true)); fclose(fid);
save(fullfile(out,'experiment.mat'),'metrics','curves','predictions','intervals','trace','models','P','cfg','groups','datasetTable','featureTable','manifest','-v7.3');
sefr_make_figures(out);
fid=fopen(fullfile(out,'COMPLETE.txt'),'w'); fprintf(fid,'Completed in MATLAB %s at %s.\n',version,char(datetime('now','TimeZone','UTC'))); fclose(fid);
if isfile(fullfile(out,'FAILED.txt')), delete(fullfile(out,'FAILED.txt')); end
result=metrics;
end
