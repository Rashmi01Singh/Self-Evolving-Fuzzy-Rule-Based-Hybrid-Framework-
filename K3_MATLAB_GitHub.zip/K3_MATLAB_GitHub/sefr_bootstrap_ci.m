function T = sefr_bootstrap_ci(y,p,threshold,reps)
% Stratified IID bootstrap conditional on observed class counts. Temporal
% dependence is not modelled: these intervals are descriptive, not deployment guarantees.
positive=find(y==1); negative=find(y==0);
names=["Sensitivity","Specificity","Precision","F1","MCC","ROCAUC","AveragePrecision"];
values=zeros(reps,numel(names));
for b=1:reps
    ix=[positive(randi(numel(positive),numel(positive),1));negative(randi(numel(negative),numel(negative),1))];
    m=sefr_metrics(y(ix),p(ix),threshold);
    for j=1:numel(names), values(b,j)=m.(names(j)); end
end
T=table(names',quantile(values,.025,1)',quantile(values,.975,1)','VariableNames',{'Metric','Lower95','Upper95'});
end
