function value = sefr_hash_file(file)
md=java.security.MessageDigest.getInstance('SHA-256');
fid=fopen(file,'rb'); assert(fid>=0,'Cannot read hash input.'); cleanup=onCleanup(@()fclose(fid));
while ~feof(fid), bytes=fread(fid,1048576,'*uint8'); md.update(typecast(bytes,'int8')); end
value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
