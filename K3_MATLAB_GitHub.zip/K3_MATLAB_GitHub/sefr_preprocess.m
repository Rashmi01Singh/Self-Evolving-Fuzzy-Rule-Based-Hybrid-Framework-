function [X,P] = sefr_preprocess(D,train)
% Fit category frequencies, medians and scaling strictly on the training partition.
if isfield(D,'raw')
    X=zeros(height(D.raw),width(D.raw)); P.encoding=cell(1,width(D.raw));
    for j=1:width(D.raw)
        v=D.raw{:,j};
        if iscell(v)||isstring(v)||iscategorical(v)
            v=string(v); v(ismissing(v))="<missing>";
            [keys,~,g]=unique(v(train)); counts=accumarray(g,1);
            [known,loc]=ismember(v,keys); z=zeros(size(v));
            z(known)=counts(loc(known))/numel(train); % unseen categories map to 0
            X(:,j)=z; P.encoding{j}=struct('keys',keys,'frequencies',counts/numel(train));
        else
            X(:,j)=double(v);
        end
    end
else
    X=D.X; P.encoding=cell(1,size(X,2));
end
X(~isfinite(X))=NaN;
P.median=median(X(train,:),1,'omitnan'); P.median(~isfinite(P.median))=0;
for j=1:size(X,2), X(isnan(X(:,j)),j)=P.median(j); end
% Robust train-only range, with clipping documented for every model.
P.low=quantile(X(train,:),0.005,1); P.high=quantile(X(train,:),0.995,1);
P.range=P.high-P.low; P.range(P.range<eps)=1;
X=min(1,max(0,(X-P.low)./P.range));
P.names=D.names;
assert(all(isfinite(X),'all'),'Nonfinite preprocessed values.');
end
