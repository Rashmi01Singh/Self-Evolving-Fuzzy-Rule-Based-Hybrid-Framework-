function cfg = default_config(root)
% All implementation choices missing from the source paper are explicit here.
if nargin == 0, root = fileparts(mfilename('fullpath')); end
cfg.root = root;
cfg.seed = 20261003;
cfg.datasets = ["ulb", "ieee"];
cfg.trainFraction = 0.60;
cfg.validationFraction = 0.20;
cfg.maxRows = Inf;              % finite values are diagnostic runs, never full results
cfg.rulesPerClass = 5;
cfg.maxRules = 18;              % per module
cfg.maxClusterRows = 20000;
cfg.featuresPerGroup = 4;
cfg.fouHalfWidth = 0.025;
cfg.sigmaMin = 0.08;
cfg.sigmaMax = 0.35;
cfg.evolutionBlocks = 9;
cfg.proposalFraction = 0.6;
cfg.thetaAdd = 0.3;
cfg.thetaFire = 0.1;
cfg.thetaModify = 0.8;
cfg.thetaDelete = 0.015;
cfg.learningRate = 0.02;
cfg.gradientStep = 1e-3;
cfg.complexityPenalty = 1e-4;
cfg.gateImprovement = 1e-4;
cfg.forestTrees = 100;
cfg.boostTrees = 100;
cfg.bootstrapReplicates = 200;
cfg.latencyRows = 100;
cfg.batchSize = 8192;
cfg.thresholdObjective = "F1";
cfg.profile = "full";
end
