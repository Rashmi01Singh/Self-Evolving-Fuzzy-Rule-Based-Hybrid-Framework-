function regenerate_figures(dataset,profile)
% Recreate figure exports from saved experiment.mat files without training.
arguments
    dataset (1,1) string {mustBeMember(dataset,["all","ulb","ieee"])} = "all"
    profile (1,1) string {mustBeMember(profile,["full","quick"])} = "full"
end
root=fileparts(mfilename('fullpath'));
addpath(root);
datasets=dataset;
if dataset=="all", datasets=["ulb","ieee"]; end
for name=datasets
    folder=fullfile(root,'results',profile,name);
    assert(isfile(fullfile(folder,'experiment.mat')), ...
        'Missing saved experiment for %s. Run run_all first.',name);
    sefr_make_figures(folder);
end
end
