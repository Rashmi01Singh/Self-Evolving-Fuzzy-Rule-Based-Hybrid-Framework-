function loss = sefr_balanced_loss(y,p)
p=min(1-1e-9,max(1e-9,p));
if numel(unique(y))<2, loss=Inf; return; end
loss=-0.5*(mean(log(p(y==1)))+mean(log(1-p(y==0))));
end
